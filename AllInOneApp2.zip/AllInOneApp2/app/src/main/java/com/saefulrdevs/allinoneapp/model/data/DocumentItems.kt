package com.saefulrdevs.allinoneapp.model.data

import com.saefulrdevs.allinoneapp.R

val documentItems = listOf(
    DocumentItem(
        1,
        "Makalah Arsikom",
        "hours ago",
        "DOCX",
        R.drawable.icon_word
    ),
    DocumentItem(
        2,
        "PPT Arsikom",
        "one day ago",
        "PPTX",
        R.drawable.icon_powerpoint
    ),
    DocumentItem(
        3,
        "Laprak modul 7",
        "a time ago",
        "PDF",
        R.drawable.icon_pdf
    ),
    DocumentItem(
        4,
        "Laporan keuangan",
        "one month ago",
        "XLSX",
        R.drawable.icon_excel
    )
)