package com.saefulrdevs.allinoneapp

import androidx.compose.material3.DrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import com.saefulrdevs.allinoneapp.about.AboutScreen
import com.saefulrdevs.allinoneapp.compress.CompressScreen
import com.saefulrdevs.allinoneapp.convert.ConvertScreen
import com.saefulrdevs.allinoneapp.home.HomeScreen

@OptIn(ExperimentalMaterial3Api::class)
fun NavGraphBuilder.mainGraph(
    drawerState: DrawerState
    ) {
    navigation(startDestination = MainNavOption.HomeScreen.name, route = NavRoutes.MainRoute.name) {
        composable(MainNavOption.HomeScreen.name){
            HomeScreen(
                drawerState = drawerState
            )
        }
        composable(MainNavOption.CompressScreen.name){
            CompressScreen(drawerState)
        }
        composable(MainNavOption.ConvertScreen.name){
            ConvertScreen(drawerState)
        }
        composable(MainNavOption.AboutScreen.name){
            AboutScreen(drawerState)
        }
    }
}

enum class MainNavOption {
    HomeScreen,
    CompressScreen,
    ConvertScreen,
    AboutScreen,
}