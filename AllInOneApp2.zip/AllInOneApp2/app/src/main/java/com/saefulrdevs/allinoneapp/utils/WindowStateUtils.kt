package com.saefulrdevs.allinoneapp.utils

enum class ReplyContentType {
    SINGLE_PANE, DUAL_PANE
}