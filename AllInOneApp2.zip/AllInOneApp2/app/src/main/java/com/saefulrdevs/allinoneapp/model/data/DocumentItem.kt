package com.saefulrdevs.allinoneapp.model.data

data class DocumentItem(
    val id: Int,
    val docName: String,
    val docTime: String,
    val docType: String,
    val docImage: Int
)
