package com.saefulrdevs.allinoneapp.model.data

import com.saefulrdevs.allinoneapp.R

val menuItem = listOf(
    MenuItem(
        1,
        R.drawable.ic_read_doc,
        "People Read Document",
        "Read Doc"
    ),
    MenuItem(
        2,
        R.drawable.ic_doc_convert,
        "Convert Document",
        "Convert Doc"
    ),
    MenuItem(
        3,
        R.drawable.ic_people,
        "People",
        "People Read Pdf"
    )
)