package com.saefulrdevs.allinoneapp.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.saefulrdevs.allinoneapp.model.data.DocumentItem
import com.saefulrdevs.allinoneapp.model.data.FeatureItem
import com.saefulrdevs.allinoneapp.model.data.MenuItem
import com.saefulrdevs.allinoneapp.model.data.featureItems
import com.saefulrdevs.allinoneapp.model.data.menuItem
import com.saefulrdevs.allinoneapp.ui.app.components.Documentlist
import com.saefulrdevs.allinoneapp.ui.app.components.ReplyDockedSearchBar


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController
) {
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {}) {
                Icon(Icons.Filled.Add, "Add")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier.padding(
                PaddingValues(
                    0.dp,
                    0.dp,
                    0.dp,
                    innerPadding.calculateBottomPadding()
                )
            )
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                MyLazyVerticalGrid(
                    featureItems,
                    navController = navController
                )
                MyLazyColumns(menuItem)
            }
        }
    }
}

@Composable
fun HistoryScreen(
    documentList: List<DocumentItem>,
) {
    Column {
        ReplyDockedSearchBar(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        )
        LazyColumn() {
            items(documentList,  key = { it.id }) {items ->
                Documentlist(
                    painter = painterResource(id = items.docImage),
                    docName = items.docName,
                    docTime = items.docTime,
                    docType = items.docType,
                )
            }
        }
    }
}

@Composable
fun AccountScreen() {
    val profileScreenController = remember { ProfileScreenController() }

    ProfileScreen(profileScreenController) {
        profileScreenController.onGoBack = {
            // Implementasi yang sesuai untuk kembali
        }
    }
}

class ProfileScreenController {
    var onGoBack: () -> Unit = {}
}

@Composable
fun ImageMenu(
    painter: Painter,
    contentDescription: String,
    title: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Box(modifier = Modifier.height(200.dp)) {
            Image(
                painter = painter,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop
            )
            Box(modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black
                        ),
                        startY = 300f
                    )
                )
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Text(title, style = TextStyle(color = Color.White, fontSize = 16.sp))
            }
        }
    }
}

@Composable
fun CardMenu(
    painter: Painter,
    featureName: String,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth(0.5f)
            .padding(15.dp),
//            .clickable(onClick = onClick), next update
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Row(
            modifier = Modifier.padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painter,
                contentDescription = null, // Anda dapat memberikan deskripsi yang sesuai
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = featureName,
                fontWeight = FontWeight.W900,
                fontSize = 18.sp
            )
        }
    }
}

@Composable
fun MyLazyVerticalGrid(
    itemsList: List<FeatureItem>,
    navController: NavController
) {
    val itemModifier = Modifier
        .border(1.dp, Color.Blue)
        .height(80.dp)
        .wrapContentSize()

    LazyVerticalGrid(
        columns = GridCells.Fixed(2)
    ) {
        items(itemsList) {items ->
            CardMenu(
                modifier = itemModifier,
                painter = painterResource(id = items.featureImage),
                featureName = items.featureName,
                onClick = {
                    navController.navigate("detail/${items.featureName}")
                }
            )
        }
    }
}

@Composable
fun MyLazyColumns(itemList: List<MenuItem>) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(space = 8.dp)
    ) {
        items(itemList) {items ->
            ImageMenu(
                painter = painterResource(id = items.imageRes),
                contentDescription = items.contentDescription,
                title = items.title
            )
        }
    }
}



