package com.saefulrdevs.allinoneapp.model.data

data class FeatureItem(
    val id: Int,
    val featureName: String,
    val featureImage: Int
)
