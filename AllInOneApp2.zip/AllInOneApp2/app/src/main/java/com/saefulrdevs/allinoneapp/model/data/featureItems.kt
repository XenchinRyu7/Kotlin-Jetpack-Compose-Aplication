package com.saefulrdevs.allinoneapp.model.data

import com.saefulrdevs.allinoneapp.R

val featureItems = listOf(
    FeatureItem(
        1,
        featureName = "Compress",
        R.drawable.ic_compress
    ),
    FeatureItem(
        2,
        featureName = "Image To PDF",
        R.drawable.ic_img_topdf
    ),
    FeatureItem(
        3,
        featureName = "Convert",
        R.drawable.ic_convert
    )
)