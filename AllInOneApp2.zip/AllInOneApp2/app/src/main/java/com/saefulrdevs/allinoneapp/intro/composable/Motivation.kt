package com.saefulrdevs.allinoneapp.intro.composable

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.saefulrdevs.allinoneapp.intro.IntroNavOption

@Composable
fun MotivationScreen(navController: NavController) = IntroCompose(
    navController = navController,
    text = "Motivation"
) {
    navController.navigate(IntroNavOption.RecommendationScreen.name)
}