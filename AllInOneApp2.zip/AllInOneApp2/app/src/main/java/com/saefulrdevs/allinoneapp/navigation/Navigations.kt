package com.saefulrdevs.allinoneapp.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.saefulrdevs.allinoneapp.model.data.documentItems
import com.saefulrdevs.allinoneapp.screens.AccountScreen
import com.saefulrdevs.allinoneapp.screens.HistoryScreen
import com.saefulrdevs.allinoneapp.screens.HomeScreen

@Composable
fun Navigations(
    navController: NavHostController,
) {
    NavHost(navController, startDestination = NavigationItem.Home.route) {
        composable(NavigationItem.Home.route) {
            HomeScreen(navController = navController)
        }
        composable(NavigationItem.History.route) {
            HistoryScreen(
                documentList = documentItems
            )
        }
        composable(NavigationItem.Account.route) {
            AccountScreen()
        }
    }
}