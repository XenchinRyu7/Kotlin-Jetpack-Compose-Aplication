package com.saefulrdevs.allinoneapp.convert

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.saefulrdevs.allinoneapp.ui.app.components.appbar.AppBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConvertScreen(
    drawerState: DrawerState,
) {
    Scaffold(
        topBar = {
            AppBar(
                drawerState = drawerState,
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(it),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ConvertDoc()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionDocument(
    docList: List<String>,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var textFieldValue by remember { mutableStateOf("") }

    // container for textfield and menu
    ExposedDropdownMenuBox(
        modifier = modifier,
        expanded = expanded,
        onExpandedChange = {
            expanded = !expanded
        }
    ) {
        // textfield
        TextField(
            modifier = Modifier
                .menuAnchor(), // menuAnchor modifier must be passed to the text field for correctness
            value = textFieldValue,
            onValueChange = { newValue ->
                textFieldValue = newValue
            },
            label = { Text("Choose") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = ExposedDropdownMenuDefaults.textFieldColors(),
        )

        // filter options based on text field value
        val filteringOptions = docList.filter { it.contains(textFieldValue, ignoreCase = true) }
        if (filteringOptions.isNotEmpty()) {
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
            ) {
                filteringOptions.forEach { selectedMovie_ ->
                    DropdownMenuItem(
                        text = { Text(selectedMovie_) },
                        onClick = {
                            textFieldValue = selectedMovie_
                            expanded = false
                        },
                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding,
                    )
                }
            }
        }
    }
}

@Preview
@Composable
fun ConvertDoc() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp)
        ) {
            OptionDocument(
                modifier = Modifier.weight(1f),
                docList = listOf("Word", "PPT", "PDF", "Excel")
            )
            Text(text = "TO", style = MaterialTheme.typography.titleLarge, modifier = Modifier.align(Alignment.CenterVertically))
            OptionDocument(
                modifier = Modifier.weight(1f),
                docList = listOf("Word", "Image", "PDF")
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { /*TODO*/ },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text(text = "Convert", style = MaterialTheme.typography.titleLarge)
        }
    }
}






