package com.saefulrdevs.allinoneapp.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.List
import androidx.compose.ui.graphics.vector.ImageVector

sealed class NavigationItem(var route: String, val icon: ImageVector?, var title: String) {
    object Home : NavigationItem("Home", Icons.Rounded.Home, "Home")
    object History : NavigationItem("History", Icons.Rounded.List, "History")
    object Account : NavigationItem("Account", Icons.Rounded.AccountCircle, "Account")
}