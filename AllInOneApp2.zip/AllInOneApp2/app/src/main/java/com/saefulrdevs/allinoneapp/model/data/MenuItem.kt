package com.saefulrdevs.allinoneapp.model.data

data class MenuItem(
    val id: Int,
    val imageRes: Int,
    val contentDescription: String,
    val title: String
)
